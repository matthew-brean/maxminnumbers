/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-09-19
* Created for: ICS4U
* Daily Assignment: Unit #1-08
* This program calls a procedure to get random numbers 
* and tells user the minimum and maximum of the numbers
*******************************************************************************/

import java.util.Scanner;
import java.util.Random;


public class MaxMinNumbers {

	
	public static int Min(int[] arraythatwaspassedin) {
		
		int i = 0;
		int min = 100;
		int randomNumber;
		
        while (i < 10){
            randomNumber = arraythatwaspassedin[i];
			if (randomNumber < min){
				min = randomNumber;
			}
        	i++; 
        }
		
		while (i < 10){

		}
		return min;

	}
	
	public static int Max(int[] arraythatwaspassedin) {
		
		int i = 0;
		int max = 0;
		int randomNumber;
		
        while (i < 10){
            randomNumber = arraythatwaspassedin[i];
			if (randomNumber > max){
				max = randomNumber;
			}
        	i++; 
        }
		
		while (i < 10){

		}
		return max;

	}
	
	public static void main(String[] args) {
		Random rand = new Random();
		
		
        // declares an array of integers
        int[] anArray;

        // allocates memory for 10 integers
        anArray = new int[10];
           
        int i = 0;
        int randomNumber;
        while (i < 10){
        	randomNumber = rand.nextInt(100) + 0; //0-100 generate #
            anArray[i] = randomNumber;
        	System.out.println("#" + i + ": " + randomNumber);
        	i++; 
        }
        
        int lowestNumber;
        int highestNumber;
      	lowestNumber = Min(anArray);
      	System.out.println("Lowest #: "+lowestNumber);
      	highestNumber = Max(anArray);
      	System.out.println("Highest #: "+highestNumber);
      

	}

}
